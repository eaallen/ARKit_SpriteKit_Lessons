//
//  Scene.swift
//  LyndaARGame
//
//  Created by Brian Advent on 21.05.18.
//  Copyright © 2018 Brian Advent. All rights reserved.
//

import SpriteKit
import ARKit

class MainMenuScene: SKScene {
    
    
}
